import com.bluepay.WebLink;

/**
 * wltest is provided as a simple example and test of WebLink.
 *
 * See the sourcecode for details.
 *
 */
public class wltest
{
  public static void main(String[] args)
  {
    WebLink wl = new WebLink("https://secure.bluepay.com/interfaces/bp10emu",
                             "123412341234",
                             "abcdabcdabcdabcdabcdabcdabcdabcd",
                             "TEST");
    wl.sale("2.00");
    wl.setCard("4111111111111111",
               "0606",
               "Test Transaction",
               "123");
    wl.setAddress("123 Foo Street",
                  "Bluepay Town",
                  "IL",
                  "60653");
    try
    {
     wl.process();
    }
    catch (Exception ex)
    {
      System.out.println("Exception: " + ex.toString());
      System.exit(1);
    }
    System.out.println("ResultCode: " + wl.getResultCode());
    if(wl.isError())
    {
      System.out.println("Error: " + wl.getMessage());
    }
    else if(wl.isApproved() || wl.isDeclined())
    {
      System.out.println("ResultCode: " + wl.getResultCode() + " TransID: " + wl.getTransID());
      System.out.println("Message: " + wl.getMessage());
    }
    else 
    {
      System.out.println("But that's unpossible!");
    }
  }
}
    


