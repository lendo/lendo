package com.bluepay;

/**
 * This exception indicates something went wrong, and the transaction was not processed.
 *
 */
public class PreTransactionException extends Exception
{
  PreTransactionException(String problem)
  {
    super(problem);
  }
}

