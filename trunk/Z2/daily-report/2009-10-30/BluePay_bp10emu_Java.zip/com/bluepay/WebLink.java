package com.bluepay;

import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import java.net.URLEncoder;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.util.StringTokenizer;
import java.util.Hashtable;
import java.io.*;

/**
 * WebLink is an interface to Bluepay's payment gateway.  This class is designed to
 * make online payments easy.
 * <p>
 * Example:
 * <p>
 * <pre>
 *  import com.bluepay.WebLink;
 *
 *  WebLink wl = new WebLink("https://secure.bluepay.com/interfaces/bp10emu", // URL
 *                           "1234123412341234",                 // Account ID,
 *                           "abcdefghijklmnopqrstuvwxyzabcdef", // Secret Key
 *                           "TEST"                              // Mode
 *                           );
 *  wl.sale("1.00");
 *  wl.setCard("4111111111111111",
 *             "0606",
 *             "Test Transaction",
 *             "123");
 *  wl.setAddress("123 Foo Street",
 *                "Bluepay Town",
 *                "IL",
 *                "60653");
 *  wl.process();
 * </pre>                               
 *                              
 */
public class WebLink
{

  private Hashtable ht = new Hashtable(); // Stores result parameters returned from Bluepay
  private boolean DEBUG = false; 

  private String BP_URL = "";
  private String BP_ACCOUNT_ID = "";
  private String BP_SECRET_KEY = "";
  private String BP_MODE = "";

  private String TRANSACTION_TYPE = "";
  private String CC_NUM = "";
  private String CVCCVV2 = "";
  private String CC_EXPIRES = "";
  private String AMOUNT = "";
  private String AMOUNT_TAX = "";
  private String AMOUNT_TIP = "";
  private String NAME = "";
  private String ADDR1 = "";
  private String ADDR2 = "";
  private String CITY = "";
  private String STATE = "";
  private String ZIPCODE = "";
  private String PHONE = "";
  private String EMAIL = "";
  private String COMMENT = "";
  private String ORDER_ID = "";
  private String INVOICE_ID = "";
  private String CUSTOM_ID = "";
  private String REBILLING = "0";
  private String REB_FIRST_DATE = "";
  private String REB_EXPR = "";
  private String REB_CYCLES = "";
  private String REB_AMOUNT = "";
  private String RRNO = "";
  private String AUTOCAP = "0";
  private String AVS_ALLOWED  = "";
  private String CVV2_ALLOWED  = "";

  /**
   * Sole constructor.  Requires merchant credentials.
   *
   * @param url A string containing the URL of the WebLink interface (probably "https://secure.bluepay.com/interfaces/bp10emu")
   * @param aid A string containing the merchant's Account ID.  A 12-digit numeral.
   * @param key A string contianing the merchant's Secret Key.  32 characters, alphanumeric.
   * @param mode A string indicating the desired processing mode, "TEST" or "LIVE"
   *
   */
  public WebLink(String url, String aid, String key, String mode)
  {
    BP_URL = url;
    BP_ACCOUNT_ID = aid;
    BP_SECRET_KEY = key;
    BP_MODE = mode;
  }

  /**
   * Sets up object to process a SALE.  A SALE both authorizes the card and captures the funds in one step.
   * 
   * In general, a SALE is the correct transaction type to use.  Use AUTH only if you have special needs.
   *
   * @param amount A string containing the amount of the transaction, e.g. "10.00"
   *
   */
  public void sale(String amount)
  {
    TRANSACTION_TYPE = "SALE";
    AMOUNT = amount;
  }

  /**
   * Sets up the object to process an AUTH.  An auth authorizes payment and garuntees the funds for later 
   * CAPTURE, but it does not transfer funds.  You must perform a CAPTURE or use Autocap.
   *
   * AUTOCAP is mostly deprecated; it was intended to be used to aid in AVS/CVV2 scrubbing, however AVS/CVV2 
   * scrubbing is now available on SALE transactions as well.
   * 
   * @param amount A string containing the amount of the transaction, e.g. "10.00"
   * @param autocap DEPRECATED. A boolean indicating whether to automatically capture the funds (optional)
   *
   */
  public void auth(String amount, boolean autocap)
  {
    TRANSACTION_TYPE = "AUTH";
    AMOUNT = amount;
    if(autocap)
      AUTOCAP = "1";
  }
  public void auth(String amount)
  {
    TRANSACTION_TYPE = "AUTH";
    AMOUNT = amount;
  }

  /**
   * Sets up the object to perform a REFUND or VOID.  The actual transaction performed will depend on the
   * original transaction status, especially whether it's batch has settled or not.
   *
   * @param transid A string containing the 12-digit transaction ID of the transaction to refund.
   * @param amount  An optional string containing the amount to refund.  By default, the entire original transaction is refunded.
   * 
   */
  public void refund(String transid, String amount)
  {  
    TRANSACTION_TYPE = "REFUND";
    RRNO = transid;
    AMOUNT = amount;
  }
  public void refund(String transid)
  {
    TRANSACTION_TYPE = "REFUND";
    RRNO = transid;
  }
 
  /**
   * Sets up the object to CAPTURE a previous AUTH.  
   *
   * @param transid A string containing the 12-digit transaction ID of the AUTH to CAPTURE.
   * @param amount  An optional string containing the amount to capture.  By default, the entire original amount is captured.
   *
   */
  public void capture(String transid, String amount)
  {
    TRANSACTION_TYPE = "CAPTURE";
    RRNO = transid;
    AMOUNT = amount;
  }
  public void capture(String transid)
  {
    TRANSACTION_TYPE = "CAPTURE";
    RRNO = transid;
  }

  /**
   * Sets the credit card values.  Required for SALE and AUTH.
   *
   * @param cardnum A string containing the Credit card number, all digits -- do not include spaces or dashes.  
   * @param expire A string containing the card's expiration date in MMYY format.
   * @param name A string containing the name printed on the card.  This is a requirement.
   * @param cvv2 A (sometimes) optional string containing the Card Verification Value -- the 3 digit number printed on the back of most cards.  Whether it is in fact optional depends on your credit card processing network's requirements.
   *
   */
  public void setCard(String cardnum, String expire, String name, String cvv2)
  {
    CC_NUM = cardnum;
    NAME = name;
    CC_EXPIRES = expire;
    CVCCVV2 = cvv2;
  }
  public void setCard(String cardnum, String expire, String name)
  {
    CC_NUM = cardnum;
    NAME = name;
    CC_EXPIRES = expire;
  }


  /**
   * Sets the billing address.  While this is technically optional, it is highly recommended.  Some 
   * payment processors may require this information.
   *
   * @param street1 A string containing the first line of the street address
   * @param city A string containing the billing city
   * @param state A string containing the billing state, province, or regional equivalent
   * @param zip A string continaing the postal code
   * @param street2 An optional string containing the second line of the street address, e.g. "Suite R"
   *
   */
  public void setAddress(String street1, String city, String state, String zip, String street2)
  {
    ADDR1 = street1;
    CITY = city;
    STATE = state;
    ZIPCODE = zip;
    ADDR2 = street2;
  }
  public void setAddress(String street1, String city, String state, String zip)
  {
    ADDR1 = street1;
    CITY = city;
    STATE = state;
    ZIPCODE = zip;
  }

  public void setTax(String taxAmount)
  {
    AMOUNT_TAX = taxAmount;
  }
  public void setTip(String tipAmount)
  {
    AMOUNT_TIP = tipAmount;
  }
  public void setOrderID(String oid)
  {
    ORDER_ID = oid;
  }
  public void setInvoiceID(String iid)
  {
    INVOICE_ID = iid;
  }

  /**
   * Adds a comment to a transaction.
   *
   * @param comment A string containing an optional comment.
   *
   */
  public void setComment(String comment)
  {
    COMMENT = comment;
  }

  /** 
   * Sets the customer's phone number.
   *
   * @param phonenum A string containing the phone number.  It should contain digits only, no punctuation.
   *
   */
  public void setPhone(String phonenum)
  {
    PHONE = phonenum;
  }

  /**
   * Sets the customer's email address.  Required if you expect them to get an email receipt from Bluepay.
   *
   * @param email A string containing the email address.  
   *
   */
  public void setEmail(String email)
  {
    EMAIL = email;
  }
  
  /**
   * Adds rebilling to an AUTH or SALE.  
   *
   * @param amount A string containing the amount to rebill.
   * @param first  A string containing the first rebilling date; can contain either a date in ISO format or a date expression such as "1 MONTH" to begin rebilling 1 month from now.
   * @param expr A string containing the Rebilling Expression; this indicates how often to rebill.  E.g. "1 MONTH" will rebill monthly; "365 DAY" or "1 YEAR" will rebill annually.
   * @param cycles A string containing the number of times to rebill; optional.  Will rebill forever if not set.
   *
   */
  public void add_rebill(String amount, String first, String expr, String cycles)
  {
    REBILLING = "1";
    REB_AMOUNT = amount;
    REB_FIRST_DATE = first;
    REB_EXPR = expr;
    REB_CYCLES = cycles;
  }
  public void add_rebill(String amount, String first, String expr)
  {
    REBILLING = "1";
    REB_AMOUNT = amount;
    REB_FIRST_DATE = first;
    REB_EXPR = expr;
  }

  /** 
   * Adds AVS scrubbing.   DEPRECATED. This field can still be used to override the AVS
   * scrubbing options selected in the gateway -- but in general it's best to leave it
   * and rely on the settings in the gateway for scrubbing.
   *
   *
   * @param accepted A string containing the accepted AVS codes, e.g. "WXY_"
   *
   */
  public void add_avs_scrubbing(String accepted)
  {
    AVS_ALLOWED = accepted;
  }

  /** 
   * Adds CVV2 scrubbing.  DEPRECATED. This field can still be used to override the CVV2 
   * scrubbing options selected in the gateway -- but in general it's best to leave it
   * and rely on the settings in the gateway for scrubbing.
   *
   * @param accepted A string containing the accepted CVV2 codes, e.g. "WXY_"
   *
   */
  public void add_cvv2_scrubbing(String accepted)
  {
    CVV2_ALLOWED = accepted;
  }

  /**
   * Calculates a hex MD5 based on input.
   *
   * @param message String to calulate MD5 of.
   *
   */
  private String md5(String message)
    throws java.security.NoSuchAlgorithmException
  {
    String digest = "";
    MessageDigest md5 = null;
    try
    {
      md5 = MessageDigest.getInstance("MD5");
    }
    catch (java.security.NoSuchAlgorithmException ex)
    {
      ex.printStackTrace();
      if(DEBUG)
      {
        System.err.println(ex.toString());
      }
      throw ex;
    }
    byte[] dig = md5.digest((byte[]) message.getBytes());
    StringBuffer code = new StringBuffer();
    for (int i = 0; i < dig.length; ++i)
    {
      code.append(Integer.toHexString(0x0100 + (dig[i] & 0x00FF)).substring(1));
    }
    return code.toString();

    //System.out.println("Message: " + message);
    //System.out.println("Digest: " + digest);

  }

  private String calc_tps()
    throws java.security.NoSuchAlgorithmException
  {
    String message = BP_SECRET_KEY + BP_ACCOUNT_ID + TRANSACTION_TYPE + AMOUNT + REBILLING +
                     REB_FIRST_DATE + REB_EXPR + REB_CYCLES + REB_AMOUNT + RRNO + AVS_ALLOWED +
                     AUTOCAP + BP_MODE;
    return md5(message);
  }

  /**
   * Processes a payment.  This is the big deal.  After calling this function, the get functions
   * can be used to retrieve the results.
   * 
   */
  public void process()
    throws PreTransactionException, 
           PostTransactionException
  {
    URL myURL=null;
    try
    {
      myURL = new java.net.URL(BP_URL);
    }
    catch ( java.net.MalformedURLException ex )
    {
      if(DEBUG)
        System.err.println(ex.toString());
      throw new PreTransactionException("URL is malformed: " + BP_URL);
    }

    String params = "";
    try
    {
      params = "TAMPER_PROOF_SEAL=" + URLEncoder.encode(calc_tps(), "UTF-8") +
               "&MERCHANT=" + URLEncoder.encode(BP_ACCOUNT_ID, "UTF-8") +
               "&MODE=" + URLEncoder.encode(BP_MODE, "UTF-8") +
               "&TRANSACTION_TYPE=" + URLEncoder.encode(TRANSACTION_TYPE, "UTF-8") +
               "&AMOUNT=" + URLEncoder.encode(AMOUNT, "UTF-8") +
               "&REBILLING=" + URLEncoder.encode(REBILLING, "UTF-8") +
               "&REB_FIRST_DATE=" + URLEncoder.encode(REB_FIRST_DATE, "UTF-8") +
               "&REB_EXPR=" + URLEncoder.encode(REB_EXPR, "UTF-8") +
               "&REB_CYCLES=" + URLEncoder.encode(REB_CYCLES, "UTF-8") +
               "&REB_AMOUNT=" + URLEncoder.encode(REB_AMOUNT, "UTF-8") +
               "&AMOUNT_TAX=" + URLEncoder.encode(AMOUNT_TAX, "UTF-8") +
               "&AMOUNT_TIP=" + URLEncoder.encode(AMOUNT_TIP, "UTF-8") +
               "&ORDER_ID=" + URLEncoder.encode(ORDER_ID, "UTF-8") +
               "&INVOICE_ID=" + URLEncoder.encode(INVOICE_ID, "UTF-8") +
               "&CUSTOM_ID=" + URLEncoder.encode(CUSTOM_ID, "UTF-8") +
               "&CC_NUM=" + URLEncoder.encode(CC_NUM, "UTF-8") +
               "&CC_EXPIRES=" + URLEncoder.encode(CC_EXPIRES, "UTF-8") +
               "&CVCCVV2=" + URLEncoder.encode(CVCCVV2, "UTF-8") +
               "&NAME=" + URLEncoder.encode(NAME, "UTF-8") +
               "&ADDR1=" + URLEncoder.encode(ADDR1, "UTF-8") +
               "&ADDR2=" + URLEncoder.encode(ADDR2, "UTF-8") +
               "&AVS_ALLOWED=" + URLEncoder.encode(AVS_ALLOWED, "UTF-8") +
               "&CVV2_ALLOWED=" + URLEncoder.encode(CVV2_ALLOWED, "UTF-8") +
               "&AUTOCAP=" + URLEncoder.encode(AUTOCAP, "UTF-8") +
               "&CITY=" + URLEncoder.encode(CITY, "UTF-8") +
               "&STATE=" + URLEncoder.encode(STATE, "UTF-8") +
               "&ZIPCODE=" + URLEncoder.encode(ZIPCODE, "UTF-8") +
               "&COMMENT=" + URLEncoder.encode(COMMENT, "UTF-8") +
               "&PHONE=" + URLEncoder.encode(PHONE, "UTF-8") +
               "&EMAIL=" + URLEncoder.encode(EMAIL, "UTF-8") +
               "&RRNO=" + URLEncoder.encode(RRNO, "UTF-8") +
               "&MISSING_URL=nu&APPROVED_URL=nu&DECLINED_URL=nu&"; 
    }
    catch (Exception ex)
    {
      if(DEBUG)
        System.err.println(ex.toString());
      throw new PreTransactionException("Unable to generate query string." + ex.toString());
    }
    String paramsLen = String.valueOf(params.length());
    
    HttpsURLConnection hcon = null;
    try
    {
      hcon = (HttpsURLConnection) myURL.openConnection();
    }
    catch (java.io.IOException ex)
    {
      if(DEBUG)
        System.err.println(ex.toString());
      throw new PreTransactionException("Unable to generate HTTPS connection: " + ex.toString());
    }
   
    hcon.setAllowUserInteraction(false);
    hcon.setUseCaches(false);
    hcon.setDoInput(true);
    hcon.setDoOutput(true);
    hcon.setInstanceFollowRedirects(false);
    try
    {
      hcon.setRequestMethod("POST");
    }
    catch (java.net.ProtocolException ex)
    {
      if(DEBUG)
        System.err.println(ex.toString());
      throw new PreTransactionException("Unsupported protocol (HTTPS not configured correctly)");
    }
    hcon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
    hcon.setRequestProperty("Content-Length", paramsLen);
    try
    {
      OutputStream os = hcon.getOutputStream();
      OutputStreamWriter osw = new OutputStreamWriter(os);
      // send request
      osw.write(params);
      osw.flush();
      osw.close();
  
      int rescode = hcon.getResponseCode();
      if(rescode != 302)
      {
        if(DEBUG)
        {
          InputStream is = hcon.getInputStream();
          InputStreamReader isr = new InputStreamReader(is);
          BufferedReader br = new BufferedReader(isr);
          String line = null;
          System.err.println("Res:\n");
          while ( (line = br.readLine()) != null) 
          {
            System.err.println(line);
          }
          br.close();
          isr.close();
        }
        throw new PostTransactionException("Unexpected response from bluepay!");
      }
    }
    catch (java.io.IOException ex)
    {
      if(DEBUG)
        ex.printStackTrace();
      throw new PostTransactionException(ex.toString());
    }
    String loc =  hcon.getHeaderField("Location");
    loc = loc.substring(loc.indexOf('?') + 1);
    StringTokenizer st = new StringTokenizer(loc, "&");
    try
    {
      while(st.hasMoreTokens())
      {
        String tok = st.nextToken();
        int eq = tok.indexOf('=');
        String p = tok.substring(0,eq);
        String v = URLDecoder.decode(tok.substring(eq + 1), "UTF-8");
        // System.out.println("P: " + p + " V: " + v);
        ht.put(p,v);
      } 
    }
    catch (java.io.UnsupportedEncodingException ex)
    {
      if(DEBUG)
        System.err.println(ex.toString());
      throw new PostTransactionException("Unable to decode response.");
    }

  }

  /** Returns a single character indicating the result.
   *
   * @return '1' = Approved, '0' = Declined, 'E' = Error, 'M' = Missing Info, '!' = Unknown
   *
   */
  public char getResultCode()
  {
    if(ht.containsKey("Result"))
    {
      String res = (String) ht.get("Result");
      // System.out.println("Result: " + res);
      if("APPROVED".equalsIgnoreCase(res))
      {
        return '1';
      }
      if("DECLINED".equalsIgnoreCase(res))
      {
        return '0';
      }
      if("ERROR".equalsIgnoreCase(res))
      {
        return 'E';
      }
      if("MISSING".equalsIgnoreCase(res))
        return 'M';
    }
    return '!';
  }

  /**
   * Returns the transaction status.
   *
   * @return true if approved; false otherwise.
   *
   */
  public boolean isApproved()
  {
    if(ht.containsKey("Result"))
      if("APPROVED".equalsIgnoreCase((String) ht.get("Result")))
        return true;
    return false;
  }

  /** 
   * Returns the transaction status.
   *
   * @return true if Declined; false otherwise.
   *
   */
  public boolean isDeclined()
  {
    if(ht.containsKey("Result"))
      if("DECLINED".equalsIgnoreCase((String) ht.get("Result")))
        return true;
    return false;
  }
  
  /**
   * Returns the transaction status.
   *
   * @return true if error or missing information; false otherwise.
   *
   */
  public boolean isError()
  {
    if(ht.containsKey("Result"))
    {
      String res = (String) ht.get("Result");
      if(("APPROVED".equalsIgnoreCase(res)) || ("DECLINED".equalsIgnoreCase(res)))
        return false;      
    }
    return true;      
  }

  /** 
   * Returns a human-readable transaction status.
   *
   * @return A string containing the status; e.g. "Approved" or "Declined: Hold Card"
   *
   */
  public String getMessage()
  {
    if(ht.containsKey("Result"))
      if("MISSING".equalsIgnoreCase((String) ht.get("Result")))
        return (String) ht.get("Missing");
    if(ht.containsKey("MESSAGE"))
      return (String) ht.get("MESSAGE");
    return null;
  }

  /** 
   * Returns the Transaction ID.
   *
   * @return String containing 12-digit ID or null if none.
   *
   */
  public String getTransID()
  {
    if(ht.containsKey("RRNO"))
      return (String) ht.get("RRNO");
    return null;
  }
  
  /**
   * Returns the rebilling ID.
   *
   * @return String containing 12-digit ID or null if none.
   *
   */
  public String getRebillingID()
  {
    if(ht.containsKey("REB_ID"))
      return (String) ht.get("REB_ID");
    return null;
  }

  /**
   * Returns the AVS response.
   *
   * @return String containing the AVS result or null if none.
   *
   */
  public String getAVS()
  {
    if(ht.containsKey("AVS"))
      return (String) ht.get("AVS");
    return null;
  }

  /**
   * Returns the CVV2 response.
   *
   * @return String containing the CVV2 response or null if none.
   *
   */
  public String getCVV2()
  {
    if(ht.containsKey("CVV2"))
      return (String) ht.get("CVV2");
    return null;
  }

};
