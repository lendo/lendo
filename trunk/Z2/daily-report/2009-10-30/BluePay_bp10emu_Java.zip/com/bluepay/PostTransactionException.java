package com.bluepay;

/**
 * This exception indicates something went wrong, and we're not sure whether the transaction was processed.
 *
 */
public class PostTransactionException extends Exception
{
  PostTransactionException(String problem)
  {
    super(problem);
  }
}

