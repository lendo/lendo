Bluepay Java SDK
(c) 2005 Bluepay, Inc.

This code is distributed under the BSD license.  It is free to use, modify, and redistribute.
It is given in the hope that it will be useful, but is not guaranteed to do anything at all; this
code is without warranty including but not limited to warrany of fitness for a particular purpose.

The included .jar file contains source .java files, compiled .class files, and a full set of 
javadocs.

If you have any questions or comments, please contact cjansen@bluepay.com.

