To build log4jdbc, you must have Ant 1.6.5 or later installed,
and JDK 1.4 and JDK 1.6 installed.

The build.cmd file is useful for building both the jdbc 3 version (JDK 1.4) and the jdbc 4 version (under JDK 1.6) under windows.
The javadoc.cmd file is useful for building javadoc (requires the 3rd party ydoc tool)
