

document.write('<p class="footer">')
document.write('Copyright &copy; 2004-2007  <a href="http://www.qos.ch/">QOS.ch</a>')
document.write('</p>')
