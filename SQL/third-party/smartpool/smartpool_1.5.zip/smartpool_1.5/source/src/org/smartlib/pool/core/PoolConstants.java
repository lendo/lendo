package org.smartlib.pool.core;

/**
 * Created by IntelliJ IDEA.
 * User: kerneldebugger
 * Date: Sep 28, 2005
 * Time: 8:39:27 PM
 * To change this template use File | Settings | File Templates.
 */
public interface PoolConstants {

    // System property
    public static final String CONFIG_FILE_SYSTEM_PROPERTY = "config.file";

    public static final String TEST_CONFIG_FILE_SYSTEM_PROPERTY = "test.config.file";




}
