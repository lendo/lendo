package org.smartlib.pool.core;

import junit.framework.TestCase;
import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.Logger;
import org.smartlib.pool.core.PoolConstants;
import org.smartlib.pool.core.PoolConfig;

import java.util.Properties;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;


/**
 * Created by IntelliJ IDEA.
 * User: kerneldebugger
 * Date: Sep 28, 2005
 * Time: 8:54:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class PoolTestFixture extends TestCase {

    Logger logger  = Logger.getLogger(PoolTestFixture.class);

    protected PoolConfig getBasicPoolConfig() {
        PoolConfig config = new PoolConfig();
        config.setMultiPoolName("MultiPool-1");
        config.setAllowAnonymousConnections(true);
        config.setAutoClose(true);
        PoolConfig.ConnectionString connectionString = new PoolConfig.ConnectionString();
        connectionString.setName("MultiPool.Pool-1");
        connectionString.setConnectString("jdbc:oracle:thin:@db01.dev:1521:dev1");
        config.setConnectionString(new PoolConfig.ConnectionString[] {connectionString});
        config.setDefaultPool(true);
        config.setDetectLeaks(false);
        config.setDriver("oracle.jdbc.driver.OracleDriver");
        config.setMaxConnections(3);
        config.setMinConnections(1);
        config.setPassword("passw0rd");
        config.setUserName("sachin");
        return config;
    }

    protected PoolConfig getPoolConfigWithMultiplePools() {
        PoolConfig config = getBasicPoolConfig();

        PoolConfig.ConnectionString connectionString = new PoolConfig.ConnectionString();
        connectionString.setName("MultiPool.Pool-1");
        connectionString.setConnectString("jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=tcp)(HOST=10.102.15.212)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=DEV)(INSTANCE_NAME=DEV1)))");
        PoolConfig.ConnectionString connectionString1 = new PoolConfig.ConnectionString();
        connectionString1.setConnectString("jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=tcp)(HOST=10.102.15.213)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=DEV)(INSTANCE_NAME=DEV1)))");
        connectionString1.setName("MultiPool.Pool-2");
        config.setConnectionString(new PoolConfig.ConnectionString[] {connectionString, connectionString1});
        return config;

    }

    protected PoolConfig getPoolConfigWithMultipleExternalPools() {
        PoolConfig config = getBasicPoolConfig();

        PoolConfig.ConnectionLoaderClass connectionLoaderClass = new PoolConfig.ConnectionLoaderClass();

        connectionLoaderClass.setName("MultiPool.ConnectionProviderImpl-1");
        connectionLoaderClass.setConnectionLoaderClass("org.smartlib.pool.core.ConnectionProviderImpl1");

        PoolConfig.ConnectionLoaderClass connectionLoaderClass1 = new PoolConfig.ConnectionLoaderClass();
        connectionLoaderClass1.setConnectionLoaderClass("org.smartlib.pool.core.ConnectionProviderImpl2");
        connectionLoaderClass1.setName("MultiPool.ConnectionProviderImpl-2");
        config.setConnectionLoaderClass(new PoolConfig.ConnectionLoaderClass[] {connectionLoaderClass, connectionLoaderClass1});
        return config;

    }

    protected void testConnection(Connection conn) throws Exception {

        logger.debug("Testing Connection: " + conn);
        Statement stmt = null;
        try {
            stmt  = conn.createStatement();
            stmt.execute("Select count(*) from version");
            logger.debug("Test Passed: " + conn);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                    //Ignore
                }
            }
        }

    }

    protected void setUp() throws Exception {
        super.setUp();
        LogManager.resetConfiguration();
        Properties log4j = new Properties();

        // ----------Basic dont change
        log4j.put("log4j.appender.A1", "org.apache.log4j.DailyRollingFileAppender");
        log4j.put("log4j.appender.A1.File", "c:\\smartpool.log");
        log4j.put("log4j.appender.A1.layout", "org.apache.log4j.PatternLayout");
        log4j.put("log4j.appender.A1.layout.ConversionPattern", "[%d{ISO8601}] <%t> %-5p %c: %m%n");
        log4j.put("log4j.appender.A1.DatePattern", "'.'yyyy-MM-dd");
        log4j.put("log4j.appender.SYSTEMOUT", "org.apache.log4j.ConsoleAppender");
        log4j.put("log4j.appender.SYSTEMOUT.layout", "org.apache.log4j.PatternLayout");
        log4j.put("log4j.appender.SYSTEMOUT.layout.ConversionPattern", "[%d{ISO8601}] <%t> %-5p %c: %m%n");
        log4j.put("log4j.appender.KILL", "org.apache.log4j.FileAppender");
        log4j.put("log4j.appender.KILL.File", "/dev/null");
        log4j.put("log4j.appender.KILL.layout", "org.apache.log4j.PatternLayout");
        log4j.put("log4j.appender.KILL.layout.ConversionPattern", "[%d] %m%n");
        //--------------------------

        log4j.put("log4j.rootLogger", "WARN, SYSTEMOUT");
        log4j.put("log4j.logger.org.smartlib", "DEBUG");

        PropertyConfigurator.configure(log4j);
        if (logger.isDebugEnabled()) {
            logger.debug("Log4J Configured");
        }

        //Set the test config file name to main config file name
        System.setProperty(PoolConstants.CONFIG_FILE_SYSTEM_PROPERTY, System.getProperty(PoolConstants.TEST_CONFIG_FILE_SYSTEM_PROPERTY));


    }

    /**
     * Gets the instance name from the V$instance view, the connected user should have the required prevelige
     * @param conn
     * @return
     * @throws Exception
     */
    protected String getInstanceName(Connection conn) throws Exception {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt  = conn.prepareStatement("select instance_name from v$instance");
            rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString(1);
            }
            else {
                throw new Exception("No Rows found, should never happen");
            }
        }
        finally {
            stmt.close();
            rs.close();
        }
    }

}
