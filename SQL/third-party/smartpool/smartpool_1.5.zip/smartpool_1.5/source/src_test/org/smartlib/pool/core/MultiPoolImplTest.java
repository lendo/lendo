package org.smartlib.pool.core;

import org.apache.log4j.Logger;

import java.sql.Connection;

/**
 * Created by IntelliJ IDEA.
 * User: kerneldebugger
 * Date: Oct 1, 2005
 * Time: 11:53:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class MultiPoolImplTest extends PoolTestFixture {

    private static Logger logger = Logger.getLogger(MultiPoolImplTest.class);

    MultiPool multiPool = null;
    protected void setUp() throws Exception {
        super.setUp();
        logger.debug("=====================Start==============================");
    }

    protected void tearDown() throws Exception {
        logger.debug("======================End===============================");
        super.tearDown();
        try {
            multiPool.shutDown();
        } catch (Exception e) {
            logger.debug("Exception in tear down",e);
        }

    }

    public void testBasicConnection() throws Exception {
        PoolConfig config = getBasicPoolConfig();
        multiPool = new MultiPoolImpl(config);
        Connection conn = multiPool.getConnection();
        assertNotNull("Connection cannot be null", conn);
        testConnection(conn);
        conn.close();
    }

    public void testIfRandomConnectionsAreObtained() throws Exception {
        PoolConfig config = getPoolConfigWithMultiplePools();
        multiPool = new MultiPoolImpl(config);
        Connection conn = multiPool.getConnection();
        testConnection(conn);
        assertNotNull("Connection cannot be null", conn);
        String subPoolName = ((SmartConnection)conn).getPoolName();
        logger.debug("Connection was picked from: " + subPoolName);
        conn.close();

        conn = multiPool.getConnection();
        testConnection(conn);
        assertNotNull("Connection cannot be null", conn);
        String subPoolName1 = ((SmartConnection)conn).getPoolName();
        logger.debug("Connection was picked from: " + subPoolName1);
        conn.close();
        assertNotSame("The two pools cannot be same", subPoolName, subPoolName1);

    }

    public void testIfThreadSkickinessIsMaintained() throws Exception {

        PoolConfig config = getPoolConfigWithMultiplePools();
        config.setThreadStickiness(true);
        multiPool = new MultiPoolImpl(config);
        Connection conn = multiPool.getConnection();
        testConnection(conn);
        assertNotNull("Connection cannot be null", conn);
        String subPoolName = ((SmartConnection)conn).getPoolName();
        logger.debug("Connection 1 was picked from pool: " + subPoolName);
        String insanceName = getInstanceName(conn);
        logger.debug("Connection 1 was picked from instance: " + insanceName);
        conn.close();

        conn = multiPool.getConnection();
        testConnection(conn);
        assertNotNull("Connection cannot be null", conn);
        String subPoolName1 = ((SmartConnection)conn).getPoolName();
        logger.debug("Connection 2 was picked from pool: " + subPoolName1);
        String insanceName1 = getInstanceName(conn);
        logger.debug("Connection 2 was picked from instance: " + insanceName1);
        conn.close();
        assertEquals("The two pools should be same", subPoolName, subPoolName1);
        assertEquals("The two instances should be same", insanceName, insanceName1);

    }


    public void testIfRandomConnectionsAreObtainedForExternalPooling() throws Exception {

        PoolConfig config = getPoolConfigWithMultipleExternalPools();
        multiPool = new MultiPoolImpl(config);
        Connection conn = multiPool.getConnection();
        testConnection(conn);
        assertNotNull("Connection cannot be null", conn);
        String subPoolName = ((SmartConnection)conn).getPoolName();
        logger.debug("Connection was picked from: " + subPoolName);
        String insanceName = getInstanceName(conn);
        logger.debug("Connection 1 was picked from instance: " + insanceName);
        conn.close();

        conn = multiPool.getConnection();
        testConnection(conn);
        assertNotNull("Connection cannot be null", conn);
        String subPoolName1 = ((SmartConnection)conn).getPoolName();
        logger.debug("Connection was picked from: " + subPoolName1);
        String insanceName1 = getInstanceName(conn);
        logger.debug("Connection 2 was picked from instance: " + insanceName1);
        conn.close();
        assertNotSame("The two pools cannot be same", subPoolName, subPoolName1);
        assertNotSame("The two instances should be same", insanceName, insanceName1);

    }

    public void testIfThreadSkickinessIsMaintainedForExternalPooling() throws Exception {

        PoolConfig config = getPoolConfigWithMultipleExternalPools();
        config.setThreadStickiness(true);
        multiPool = new MultiPoolImpl(config);
        Connection conn = multiPool.getConnection();
        testConnection(conn);
        assertNotNull("Connection cannot be null", conn);
        String subPoolName = ((SmartConnection)conn).getPoolName();
        logger.debug("Connection 1 was picked from pool: " + subPoolName);
        String insanceName = getInstanceName(conn);
        logger.debug("Connection 1 was picked from instance: " + insanceName);
        conn.close();

        conn = multiPool.getConnection();
        testConnection(conn);
        assertNotNull("Connection cannot be null", conn);
        String subPoolName1 = ((SmartConnection)conn).getPoolName();
        logger.debug("Connection 2 was picked from pool: " + subPoolName1);
        String insanceName1 = getInstanceName(conn);
        logger.debug("Connection 2 was picked from instance: " + insanceName1);
        conn.close();
        assertEquals("The two pools should be same", subPoolName, subPoolName1);
        assertEquals("The two instances should be same", insanceName, insanceName1);

    }


}
