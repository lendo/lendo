package org.smartlib.pool.core;

import org.smartlib.pool.core.ConfigFileProcessor;
import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: kerneldebugger
 * Date: Aug 25, 2005
 * Time: 9:54:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConfigFileProcessorTest extends PoolTestFixture {


    Logger logger  = Logger.getLogger(ConfigFileProcessorTest.class);

    public void testIfDefaultFileLoads() throws Exception {
        ConfigFileProcessor processor = new ConfigFileProcessor();
        PoolConfig config[] = processor.getPoolConfig();
        for (int i=0; i<config.length; i++) {
            logger.debug("Configurations are: " + config[i]);
        }
    }


    public void testIfSpecificFileLoads() throws Exception {
        ConfigFileProcessor processor = new ConfigFileProcessor();
        PoolConfig config[] = processor.getPoolConfig(System.getProperty(PoolConstants.CONFIG_FILE_SYSTEM_PROPERTY));
        for (int i=0; i<config.length; i++) {
            logger.debug("Configurations are: " + config[i]);
        }
    }


}
