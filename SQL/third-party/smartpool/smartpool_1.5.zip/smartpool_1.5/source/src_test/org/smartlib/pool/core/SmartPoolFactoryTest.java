package org.smartlib.pool.core;

import java.sql.Connection;

/**
 * Created by IntelliJ IDEA.
 * User: kerneldebugger
 * Date: Oct 1, 2005
 * Time: 10:09:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class SmartPoolFactoryTest extends PoolTestFixture {

    SmartPoolFactory factory;

    protected void setUp() throws Exception {
        super.setUp();
        factory = new SmartPoolFactory();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        SmartPoolFactory.shutDown();
    }

    public void testBasicFactoryLoading() throws Exception {
        Connection conn = SmartPoolFactory.getConnection();
    }

}
